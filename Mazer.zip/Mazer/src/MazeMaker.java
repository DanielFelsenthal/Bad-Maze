import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class MazeMaker extends JPanel {
    public class mazePiece extends JPanel {
        boolean truePath;
        int pieceNum;
        boolean doubleDraw;
        int width;
        int height;
        int height2;
        int width2;
        int x1;
        int y1;
        int x2;
        int y2;

        public mazePiece() {
            doubleDraw=false;
            x1=65;
            y1=50;
            setPreferredSize( new Dimension(360,360) );
            setBackground(Color.WHITE);


        }

        public void paintComponent(Graphics g) {
            int n=0;
            while (n!=1) {
            mazePiece piece=pieceGenerator();
           piece.x1=piece.x1+n*15;
                piece.y1=piece.y1+n*15;

                g.setColor(Color.RED);
            g.fillRect(piece.x1,piece.y1,piece.width,piece.height);
            System.out.println(piece.x1+ "Yorr Yorr " + piece.y1+"Y"+ piece.height +"I" + piece.width);
            if (piece.doubleDraw==true) {
                g.setColor(Color.BLUE);
                piece.x2=piece.x2+n*15;
                piece.y2=piece.y2+n*15;
                System.out.println("drew two");
                g.fillRect(piece.x2,piece.y2,piece.width2,piece.height2);
                piece.doubleDraw=false;}
                n++;
            }
        }
    }
    public class mazeBackround extends JPanel {
        public mazeBackround() {
            setPreferredSize(new Dimension(400, 400));
            setBackground(Color.WHITE);
        }
    }


    public mazePiece pieceGenerator() {
        Random randy = new Random();
        mazePiece newPiece=new mazePiece();
        // newPiece.pieceNum=(int)((Math.random())*(6));
        newPiece.pieceNum=1;
        System.out.println(newPiece.pieceNum);
        switch (newPiece.pieceNum){
            case 0:
                newPiece.width=60;
                newPiece.height=20;
                break;
            case 1:
                newPiece.width=32;
                newPiece.height=32;
                break;

            case 2:
                newPiece.doubleDraw=true;
                newPiece.width=20;
                newPiece.height=60;
                newPiece.width2=20;
                newPiece.height2=60;
                newPiece.x2=newPiece.x1-15;
                newPiece.y2=newPiece.y1-10;
                break;

            case 3:
                newPiece.doubleDraw=true;
                newPiece.width=20;
                newPiece.height=60;
                newPiece.height2=60;
                newPiece.width2=20;
                newPiece.x2=newPiece.x1-30;
                newPiece.y2=newPiece.y1-30;
                break;

            case 4:
                newPiece.doubleDraw=true;
                newPiece.width=60;
                newPiece.height=20;
                newPiece.height2=20;
                newPiece.width2=60;
                newPiece.x2=newPiece.x1+30;
                newPiece.y2=newPiece.y1-25;
                break;

            case 5:
                System.out.print("yyy");
                newPiece.doubleDraw=true;
                newPiece.width=40;
                newPiece.height=20;
                newPiece.width2=40;
                newPiece.height2=20;
                newPiece.x2=newPiece.x1+20;
                newPiece.y2=newPiece.y2-10;
                break;

            case 6:
                newPiece.doubleDraw=true;
                newPiece.width=40;
                newPiece.height=20;
                newPiece.width2=40;
                newPiece.height2=20;
                newPiece.x2=newPiece.x1+10;
                newPiece.y2=newPiece.y2-10;
                break;

        }
        System.out.println(newPiece.height + " " + newPiece.width);
    return newPiece;
    }



    public static void main(String[] args) {
        JFrame window = new JFrame("Maze");
        MazeMaker.mazePiece obj;
        obj = (new MazeMaker().new mazePiece());
        window.setContentPane(obj);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setLocation(400,400);
        window.pack();
        window.setVisible(true);

    }
}



