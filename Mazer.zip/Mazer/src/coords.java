public class coords {
    public  coords() {
        int x;
        int y;
    }
}
