import javax.swing.*;
import java.awt.*;
import java.util.*;

public class lineMaze extends JPanel{
    queueofInts queue=new queueofInts();
    public static void printMap(Map<ArrayList<Integer>, miniSquare> mp) {
        Iterator<Map.Entry<ArrayList<Integer>,miniSquare>> it = mp.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
//            arrayPrint((int[]) pair.getKey());
            System.out.println( pair.getKey() + " = " + pair.getValue()+ "Yorr" );
            ArrayList<Integer> li=new ArrayList<>();
            li.add(0,550);
                    li.add(1,400);
            System.out.println(mp.get(li) + "Crap");

            it.remove(); // avoids a ConcurrentModificationException
        }

    }

    public void paintComponent(Graphics g) {
        HashMap mp= miniSquares(200,600,200,600);
        // printMap(mp);
        adjSetter(mp);
        ArrayList<Integer> inter=new ArrayList<Integer>();
        inter.add(0,450);
        inter.add(1,250);
        miniSquare msq=(miniSquare)mp.get(inter);
        System.out.println(msq.xCord + " " + msq.yCord);
        System.out.print("Hi!");
        inter.set(0,550);
        inter.set(1,600);
        miniSquare startSquare=(miniSquare)mp.get(inter);
        Stack<miniSquare> newStack=new Stack<>();
        findPath(startSquare, newStack);
        int startX=600;
        int startY=575;
        int endX=200;
        int endY=225;
        queue.enqueue(startX);
        queue.enqueue(startY);
        super.paintComponent( g);
        setBackground(Color.WHITE);
       // g.setColor(Color.BLACK);
        g.drawRect(200,200,400,400);
        g.setColor(Color.WHITE);
        g.drawLine(200,200,200,250);
        g.drawLine(600,600,600,550); //Fucking End
        g.setColor(Color.BLUE);
        miniSquare mSqua= newStack.pop();
        miniSquare mSqua2= newStack.pop();
        while (!newStack.empty()) {

            g.setColor(Color.BLUE);
            g.drawLine(mSqua.xCord+25,mSqua.yCord-25,mSqua2.xCord+25,mSqua2.yCord-25);
            System.out.println("The first square we did was " + mSqua.xCord + " , " + mSqua.yCord );
            System.out.println("The next was " + mSqua2.xCord + " , " + mSqua2.yCord);
            mSqua2= mSqua;
            mSqua= newStack.pop();
        }

// Middle Ender is 200,225, Middle Starter is 600,575 Top Wall is 200

    }
    public lineMaze() {

    }


    public class miniSquare {
        public ArrayList <Character> list=new ArrayList<Character>();
        boolean containsTruePath;
        boolean hasRightWall=false;
        boolean hasBotWall=false;
        boolean hasTopWall=false;
        boolean hasLeftWall=false;
        public miniSquare leftSquare;
        public miniSquare rightSquare;
        public miniSquare topSquare;
        public miniSquare bottomSquare;
         int xCord;
         int yCord;
         char correctNextPath;
         miniSquare prevSquare;
         boolean visited=false;
         boolean prevPopped=false;
        public miniSquare() {
            list.add('r');
            list.add('l');
            list.add('b');
            list.add('t');


        }
    }

        public class verticalEdge{
        int weight;
        miniSquare topSquare;
        miniSquare botSquare;
        }

        public class horizontalEdge {
        int weight;
        miniSquare rightSquare;
        miniSquare leftSquare;
        }

    
    public void adjSetter(HashMap<ArrayList<Integer>,miniSquare> mp) {
        Iterator it = mp.entrySet().iterator();
        while (it.hasNext()) {
            System.out.println("Hi~!");

            Map.Entry pair = (Map.Entry)it.next();
            ArrayList<Integer> list=(ArrayList<Integer>)pair.getKey();
            ArrayList<Integer> lis=new ArrayList<Integer>();
            lis.add(0,list.get(0));
            lis.add(1,list.get(0));
            miniSquare minSqua=(miniSquare)pair.getValue();

            System.out.println(list.get(0) + "  " + list.get(1) + "Yerr");
            if((minSqua.yCord!=600)){
                lis.set(1,minSqua.yCord+50);
                minSqua.bottomSquare=mp.get(lis);
                 System.out.println("This Square is " + minSqua.xCord + "  " +minSqua.yCord + " and its bottom square is " + lis.get(0) + " " + lis.get(1) + " And it's actually " + minSqua.bottomSquare.xCord + " " + minSqua.bottomSquare.yCord  ); }
            if(minSqua.yCord!=250){
                lis.set(1,minSqua.yCord-50);
                minSqua.topSquare=mp.get(lis);

                System.out.println("This Square is " + minSqua.xCord + "  " + minSqua.yCord + " and its top square is " + lis.get(0) + " " + lis.get(1) + " And it's actually " + minSqua.topSquare.xCord + " " + minSqua.topSquare.yCord );
                }
            if(minSqua.xCord!=550){
                lis.set(1,minSqua.yCord);
                lis.set(0,minSqua.xCord+50);
                minSqua.rightSquare=mp.get(lis);
                minSqua.hasRightWall=true;
                System.out.println("This Square is " + minSqua.xCord + "  " + minSqua.yCord + " and its right square is " + lis.get(0) + " " + lis.get(1) + " And it's actually " + minSqua.rightSquare.xCord + " " + minSqua.rightSquare.yCord );
                System.out.println(mp.get(lis).xCord+ "Yerd");}
            if(minSqua.xCord!=200){
                lis.set(1,minSqua.yCord);
                lis.set(0,minSqua.xCord-50);
                minSqua.leftSquare=mp.get(lis);
                minSqua.hasLeftWall=true;
                System.out.println("This Square is " + minSqua.xCord + "  " + minSqua.yCord + " and its left square is " + lis.get(0) + " " + lis.get(1) + " And it's actually " + minSqua.leftSquare.xCord + " " + minSqua.leftSquare.yCord );}

        }

    }
        public void wallMaker(HashMap<ArrayList<Integer>,miniSquare> map) {

    }

    public HashMap<int[],Integer> miniSquares(int y1,int y2,int x1, int x2){
        HashMap map=new HashMap();

        int smallSquareSize=50;
        int bigSquareSize=400;
        int y=600;
        int x=200;
        int numSquares=64;
        System.out.println(numSquares);
        int[] ary=new int[2];
        for(int n=0; n!=64; n++) {
            ArrayList<Integer> list=new ArrayList<Integer>();
            list.add(0);
            list.add(0);
            list.set(0,x);
            list.set(1,y);
            miniSquare mSqua=new miniSquare();
            mSqua.xCord=x;
            mSqua.yCord=y;
            map.put(list,mSqua);
            System.out.println("x is " + list.get(0) + " , and y is " + list.get(1)+ " , and size is " + map.size());



            x=x+50;
            if(map.size()%8==0) {
                x=200;
                y=y-50;

            }
        }
            return  map;
    }



public Stack findPath(miniSquare mSqua, Stack<miniSquare> stack) {
          if (mSqua.xCord==200 && mSqua.yCord==250){
         //   mSqua.containsTruePath=true;
              System.out.println("Done!");
              if (stack.size()%2!=0) {
                  miniSquare fillerSquare=stack.pop();
                  stack.push(fillerSquare);
                  stack.push(fillerSquare);
              }
              return stack;


        }
        else {
             return findPath(truePathDirectionPicker(mSqua,stack),stack);
          }


    //return stack;
}

    public miniSquare truePathDirectionPicker(miniSquare mSqua,Stack stack) {
        System.out.println("The stack currently has a size of " + stack.size());
        System.out.println("The square we're doing right now is " + mSqua.xCord + " , " + mSqua.yCord );
        System.out.println(mSqua.list.size()+ "Pequot");
        if (mSqua.yCord == 250) {
            mSqua.list.remove((Character)'t');
            mSqua.list.remove((Character)'r');
        }
        if (mSqua.yCord == 600) {
            mSqua.list.remove((Character)'b');
            mSqua.list.remove((Character)'r');
        }
        if (mSqua.xCord == 550) {
            mSqua.list.remove((Character)'r');
            mSqua. list.remove((Character)'b');
        }
        if (mSqua.xCord == 200) {
            mSqua.list.remove((Character)'l');
            mSqua.list.remove((Character)'b');
        }
        if ((mSqua.leftSquare!=null && mSqua.leftSquare.visited)) {
            mSqua.list.remove((Character)'l');
        }
        if (mSqua.rightSquare!=null && mSqua.rightSquare.visited) {
            mSqua.list.remove((Character)'r');
        }
        if (mSqua.topSquare!=null && mSqua.topSquare.visited) {
            mSqua.list.remove((Character)'t');
        }

        if (mSqua.bottomSquare!=null && mSqua.bottomSquare.visited) {
            mSqua.list.remove((Character)'b');
        }
        mSqua.list.trimToSize();
        int x=mSqua.list.size();

        System.out.println(x+ "Yorg");
        if (x==0) {
            System.out.println("Redo!");
            while (mSqua.list.size()<=1 && mSqua.prevPopped) {
                System.out.println("Popping");
                mSqua.visited=false;
                mSqua = (miniSquare) stack.pop();
                System.out.println("Yoruba" + mSqua.list.size());
               mSqua.list.remove((Character) mSqua.correctNextPath);

            }
            mSqua.prevPopped=true;
            return truePathDirectionPicker(mSqua,stack);

        }
        Random rando=new Random();
            int ranNum = rando.nextInt(x);

       System.out.println(ranNum+ "ROME");


        char direction=mSqua.list.get(ranNum);
        System.out.println(direction);
        mSqua.correctNextPath=direction;
        if (direction=='b') {
            stack.push(mSqua);
            mSqua.visited=true;
          //  mSqua.bottomSquare.prevSquare=mSqua;
            System.out.println("Going bot");

            return mSqua.bottomSquare;

        }
        else if (direction=='t') {
            stack.push(mSqua);
            mSqua.visited=true;

            mSqua.topSquare.prevSquare=mSqua;
            System.out.println("Going top");

            return mSqua.topSquare;
        }
        else if(direction=='r') {
            stack.push(mSqua);
            mSqua.visited=true;

          mSqua.rightSquare.prevSquare=mSqua;
            System.out.println("Going right");


            return mSqua.rightSquare;
        }
        else {
            stack.push(mSqua);
            mSqua.visited=true;
            mSqua.leftSquare.prevSquare=mSqua;
            System.out.println("Going left");

            return mSqua.leftSquare;
        }
        }





    public static void main (String[] args) {
        lineMaze maze=new lineMaze();
        HashMap mp= maze.miniSquares(200,600,200,600);
        // printMap(mp);
        maze.adjSetter(mp);
        ArrayList<Integer> inter=new ArrayList<Integer>();
        inter.add(0,450);
        inter.add(1,250);
        miniSquare msq=(miniSquare)mp.get(inter);
        System.out.println(msq.xCord + " " + msq.yCord);
        System.out.print("Hi!");
        inter.set(0,550);
        inter.set(1,600);
        miniSquare startSquare=(miniSquare)mp.get(inter);
        Stack<miniSquare> newStack=new Stack<>();
        maze.findPath(startSquare, newStack);
        JFrame window = new JFrame("Maze");
        window.setContentPane(maze);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500,500);
        //window.setLocation(100,100);
        window.pack();
       window.setVisible(true);
    }
}

