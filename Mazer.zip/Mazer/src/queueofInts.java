import java.util.Arrays;

public class queueofInts {
    static boolean booler=false;
    private static class Node {
        int item;
        Node next;
    }
    private static Node head=null;
    private static Node tail=null;
    public static void enqueue(int N) {
        Node newTail = new Node();
        newTail.item = N;
        if (head == null) {
            head = newTail;
            tail = newTail;
        } else {
            tail.next = newTail;
            tail = newTail;
        }
    }
    public static int dequeue() {
        if (head==null)
            throw new IllegalStateException("can't dequeue");
        int firstItem= head.item;
        head=head.next;
        return firstItem;

    }

    static boolean isEmpty() {
        return  (head==null);
    }


    public static void arrayPrint(int[] ary) {

        for (int i=0; i<ary.length; i++) {
            System.out.print(ary[i] + ", " );
            if(i%150==0 && i!=0){
                System.out.println("");
            }

        }
        System.out.println();

    }



}

